﻿Public Class Cars
    'Team 11: the Cars class is a list of Cars with their specifications
    Public Shared Property CarsList As New List(Of Cars)
    Public Property ID As Long 'Team 11: the ID is the unique identifier
    Public Property CarName As String 'Team 11: the CarName property is a string that is the name of the car
    Public Property Cost As Double 'Team 11: the Cost property is a double value that is the cost of the car
    Public Property MPG As Integer 'Team 11: the MPG property is a integer value that is the miles per gallon of the car
    Public Property Comfort As Integer 'Team 11: the Comfort property is an integer value that is the comfort value of the car
    Public Property Utility As Integer 'Team 11: the Utility property is an integer value that is the utility value of the car
    Public Property Interior As Integer 'Team11: the Interior property is an integer value that is the rating of the interior of the car
    'Team 11: this method creates a new object of Cars
    Public Sub New()


    End Sub
End Class
