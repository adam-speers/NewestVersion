﻿
Imports System.Data.OleDb                             'Team11: We use the OleDB namespace for an MS Access namespace
'**************************************************************************************************************************
Public Class DBMS
    'ADO.NET Data Provider Objects
    Private team11DataAdapter As New OleDbDataAdapter    'Team11: ADO.NET DataAdapter Object -  The DataAdapter facilitates the conversion from the external Database to the internal DataSet
    Private team11Connection As New OleDbConnection      'Team11: ADO.NET Connection Object property -  
    Private team11ConnectionString As String             'Team11: ADO.NET Connection Object property -  The connection string is found in the app.config file.  This string points to the external DataBase
    Private team11SQL As String                          'Team11: ADO.NET Command Object property - This string is declared for any SQL statements that we will write
    Private team11DataSet As New DataSet                 'Team11: ADO.NET DataSet Object - The external Database will be transformed into an internal DataSetDim orderList As New List(Of SalesOrder)
    Private team11Command As New OleDbCommand            'Team11: ADO.NET DataSet Command Object - sql commands are conveyed via a Command object
    Private team11TableName As String                    'Team11: sql Commands are executed on tables
    '**************************************************************************************************************************
    Public Sub New()
        ' This sub creates a new DBMSe object

    End Sub
    '**************************************************************************************************************************
    Public Sub RunSQL(ByVal team11TableName, ByVal team11SQL, ByVal team11DataSet, ByVal team11ConnectionString)
        '
        'Team11:  First we build the Database Connection Object
        team11Connection.ConnectionString = team11ConnectionString      'Team11:  We use the Connection String that is found in the app.config file to connect to the DataBase
        team11Command = team11Connection.CreateCommand()
        '
        'Team11: Now we build the Command that will be sent to the Data Adapter
        team11Command.CommandText = team11SQL                            'Team11: The sql is embedded in an object called a Command
        '
        'Team11: Now we build the Data Adapter
        team11DataAdapter.SelectCommand = team11Command                  'Team11: The DataAdaptor executes the query Command
        team11DataAdapter.Fill(team11DataSet, team11TableName)              'Team11: The Fill method of the DataAdaptor fills tables in the DataSet from data from the DataBase

    End Sub
End Class

