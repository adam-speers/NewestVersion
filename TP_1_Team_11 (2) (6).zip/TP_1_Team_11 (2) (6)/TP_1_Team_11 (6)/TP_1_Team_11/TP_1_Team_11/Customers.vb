﻿Public Class Customers
    'Team 11: the Customers class is a list of Customers with their specifications
    Public Shared Property CustomerList As New List(Of Customers)
    Public Property SatisfactionMeasure As String 'Team 11: the satisfaction measure is a string with the satisfaction measure
    Public Property Dplus As Integer 'Team 11: Dplus is an integer value for Dplus
    Public Property Dminus As Integer 'Team 11: Dminus is an integer value for Dminus
    Public Property Goal As Integer 'Team 11: Goal is an integer value for the user's goal
    Public Property Budget As Double 'Team 11: Budget is an integer value for the user's budget input

    Public Sub New()

    End Sub
End Class
